const Express = require('express');
const AuthService = require('../authservice')

const router = Express.Router();
const UserController = require('./user.controller');

router.post('/api/login',UserController.login)
router.post('/api/register' , UserController.createUser)
router.get('/api/users',UserController.getUsers)
router.get('/api/logout',UserController.logout)
router.post('/api/deleteuser',UserController.deleteUser)
router.post('/api/resetpassword',UserController.resetPassword)




module.exports = router;